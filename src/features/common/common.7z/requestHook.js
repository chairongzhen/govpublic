/*
 * @Author: hcluo
 * @Date: 2020-07-15 16:04:44
 * @LastEditors: hcluo
 * @LastEditTime: 2020-08-24 18:01:10
 * @Description: 政府项目
 */
import { useCallback, useState, useEffect } from 'react';
import { Toast } from '@wind/wind-ui-mobile';
import { requests } from '../../utils/request';
import { useRequest as useARequest } from 'ahooks';
import { req } from './request';
/**
 * 
    
    ERROR_ACCESS("403", "访问权限受到限制，请联系管理员"),
    ERROR_LOGIN("E00000005", "登陆失败，请稍后重试"),
    ERROR_ROLE("E00000007", "暂无权限"),
    
    ERROR_SESSION("E00000001", "session无效"),
    
    
    
    
    
    提示 ： 系统错误，请重试
    ERROR_PARAM("E00000002", "参数错误"),
    
    ERROR_BUSINESS("E00000090", "业务异常，请联系管理员"),
    
    ERROR_IO("E00000091", "IO异常"),  
    
    ERROR_NET("E00000092", "网络错误"),     
    
    ERROR_SERVICE("E00000093", "服务异常，请稍后重试"),
    
    ERROR_OTHER("E00000099", "未知异常，请联系管理员"),
 */

let toasting = false;
export default function useRequest(type = 'useGetuser', getParams, deps) {
  const [status, setStatus] = useState(typeof getParams === 'function' ? 1 : 0); // 0-已完成，1-发送中，2-返回出错
  const [data, setData] = useState({});
  const [errorMsg, setErrorMsg] = useState();
  const boundAction = useCallback(
    (...argus) => {
      setStatus(1);
      let doRequest = requests[type];
      doRequest(...argus)
        .then(res => {
          setData(res);
          setStatus(0);
        })
        .catch(err => {
          console.error('%c 🥒 err: ', 'font-size:20px;background-color: #FCA650;color:#fff;', err);
          setErrorMsg(err);
          setStatus(2);
          if (!toasting) {
            toasting = true;
            switch (err.resultCode) {
              case 'DE-E000007':
                Toast.fail(err.resultMessage, 3, () => {
                  toasting = false;
                });
                break;

              default:
                Toast.fail('系统错误', 3, () => {
                  toasting = false;
                });
                break;
            }
          }
        });
    },
    [type],
  );
  useEffect(() => {
    if (typeof getParams === 'function') {
      let params = getParams();
      params && boundAction(getParams());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return [data, status, boundAction, errorMsg];
}

export function useRequests(type = 'useGetuser', getParams, deps) {
  const [status, setStatus] = useState(typeof getParams === 'function' ? 1 : 0); // 0-已完成，1-发送中，2-返回出错
  const [data, setData] = useState({});
  const [errorMsg, setErrorMsg] = useState();

  const { loading, run } = useARequest(req, {
    manual: true,
  });

  useEffect(() => {
    run('./wwww');
  }, [run]);

  return [data, status, , errorMsg];
}

export { requests };
